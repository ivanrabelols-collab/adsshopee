from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import shopee, agent, dashboard
from app.core.config import settings

app = FastAPI(
    title="Shopee Manager API",
    description="Sistema de gestão de tráfego para Shopee com IA",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", settings.FRONTEND_URL],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(shopee.router, prefix="/api/shopee", tags=["Shopee"])
app.include_router(agent.router, prefix="/api/agent", tags=["Agente IA"])
app.include_router(dashboard.router, prefix="/api/dashboard", tags=["Dashboard"])

@app.get("/")
def root():
    return {"status": "ok", "message": "Shopee Manager API"}

@app.get("/health")
def health():
    return {"status": "healthy"}
