from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Shopee API
    SHOPEE_PARTNER_ID: str = ""
    SHOPEE_PARTNER_KEY: str = ""
    SHOPEE_SHOP_ID: str = ""
    SHOPEE_ACCESS_TOKEN: str = ""
    SHOPEE_REFRESH_TOKEN: str = ""
    SHOPEE_API_BASE: str = "https://partner.shopeemobile.com/api/v2"

    # Anthropic
    ANTHROPIC_API_KEY: str = ""

    # App
    SECRET_KEY: str = "change-me-in-production"
    FRONTEND_URL: str = "http://localhost:3000"
    DATABASE_URL: str = "sqlite:///./shopee_manager.db"

    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
