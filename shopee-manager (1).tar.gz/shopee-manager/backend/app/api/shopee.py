from fastapi import APIRouter, HTTPException, Query
from app.services.shopee_service import shopee_service

router = APIRouter()

@router.get("/dashboard")
async def get_dashboard(demo: bool = Query(True)):
    """Retorna todos os dados consolidados do dashboard"""
    if demo:
        return await shopee_service.get_mock_dashboard()
    try:
        campaigns = await shopee_service.get_ads_campaigns()
        products_list = await shopee_service.get_products()
        shop = await shopee_service.get_shop_info()
        return {"shop": shop, "campaigns": campaigns, "products": products_list}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/campaigns")
async def get_campaigns(demo: bool = Query(True)):
    if demo:
        data = await shopee_service.get_mock_dashboard()
        return data["campaigns"]
    return await shopee_service.get_ads_campaigns()

@router.get("/products")
async def get_products(demo: bool = Query(True)):
    if demo:
        data = await shopee_service.get_mock_dashboard()
        return data["products"]
    return await shopee_service.get_products()

@router.post("/campaigns/{campaign_id}/pause")
async def pause_campaign(campaign_id: int):
    return await shopee_service.pause_campaign(campaign_id)

@router.post("/campaigns/{campaign_id}/budget")
async def update_budget(campaign_id: int, daily_budget: float):
    return await shopee_service.update_campaign_budget(campaign_id, daily_budget)
