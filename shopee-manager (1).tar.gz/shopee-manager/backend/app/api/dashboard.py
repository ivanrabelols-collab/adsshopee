from fastapi import APIRouter
from app.services.shopee_service import shopee_service

router = APIRouter()

@router.get("/summary")
async def get_summary(demo: bool = True):
    data = await shopee_service.get_mock_dashboard() if demo else {}
    return data.get("summary", {})
