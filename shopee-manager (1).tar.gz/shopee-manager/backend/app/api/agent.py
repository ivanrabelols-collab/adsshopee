from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.services.agent_service import agent_service
from app.services.shopee_service import shopee_service

router = APIRouter()

class ChatRequest(BaseModel):
    message: str
    demo: bool = True

@router.post("/chat")
async def chat(req: ChatRequest):
    """Chat livre com o agente de IA"""
    data = await shopee_service.get_mock_dashboard() if req.demo else {}
    try:
        response = await agent_service.analyze(req.message, data)
        return {"response": response}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/audit")
async def full_audit(demo: bool = True):
    """Diagnóstico completo da conta"""
    data = await shopee_service.get_mock_dashboard() if demo else {}
    response = await agent_service.full_audit(data)
    return {"response": response}

@router.post("/optimize")
async def optimize(demo: bool = True):
    """Otimização de campanhas"""
    data = await shopee_service.get_mock_dashboard() if demo else {}
    response = await agent_service.optimize_campaigns(data)
    return {"response": response}

@router.post("/keywords")
async def keywords(demo: bool = True):
    """Estratégia de palavras-chave"""
    data = await shopee_service.get_mock_dashboard() if demo else {}
    response = await agent_service.keyword_strategy(data)
    return {"response": response}

@router.post("/resources")
async def resources(demo: bool = True):
    """Auditoria de recursos não usados"""
    data = await shopee_service.get_mock_dashboard() if demo else {}
    response = await agent_service.resources_audit(data)
    return {"response": response}

@router.post("/daily-report")
async def daily_report(demo: bool = True):
    """Relatório diário"""
    data = await shopee_service.get_mock_dashboard() if demo else {}
    response = await agent_service.daily_report(data)
    return {"response": response}
