import anthropic
from app.core.config import settings
from app.services.shopee_service import shopee_service


SYSTEM_PROMPT = """Você é um gestor de tráfego e e-commerce sênior especializado em Shopee.
Você tem acesso aos dados reais da loja (campanhas, produtos, métricas) e sua missão é:

1. Analisar os dados com olhar crítico de gestor experiente
2. Identificar oportunidades de melhoria imediatas e de médio prazo
3. Propor ações concretas e priorizadas (o que fazer AGORA vs depois)
4. Calcular impacto esperado de cada ação
5. Detectar problemas: campanhas com ROAS ruim, produtos parados, recursos não usados

Sempre seja direto, específico e orientado a resultado. Use os dados fornecidos.
Formate sua resposta em seções claras com emojis para facilitar leitura.
Inclua sempre: diagnóstico, ações prioritárias, e próximos passos."""


class AgentService:
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)

    async def analyze(self, question: str, context_data: dict) -> str:
        data_str = self._format_data(context_data)
        messages = [
            {
                "role": "user",
                "content": f"""Analise os dados abaixo da minha loja Shopee e responda:

{question}

--- DADOS DA LOJA ---
{data_str}
"""
            }
        ]
        response = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            system=SYSTEM_PROMPT,
            messages=messages
        )
        return response.content[0].text

    async def full_audit(self, data: dict) -> str:
        return await self.analyze(
            "Faça um diagnóstico completo da conta. Analise cada campanha, "
            "identifique os 3 maiores problemas e as 3 maiores oportunidades. "
            "Liste ações prioritárias com impacto estimado.",
            data
        )

    async def optimize_campaigns(self, data: dict) -> str:
        return await self.analyze(
            "Analise todas as campanhas de ads. Para cada uma diga: manter, pausar, "
            "escalar ou reformular. Justifique com base no ROAS, CTR e CPC. "
            "Sugira novos lances e orçamentos ideais.",
            data
        )

    async def keyword_strategy(self, data: dict) -> str:
        return await self.analyze(
            "Analise a estratégia de palavras-chave. Quais produtos precisam de novas kws? "
            "Quais categorias não estamos explorando? Sugira 10 palavras-chave de alto potencial "
            "para os produtos principais.",
            data
        )

    async def resources_audit(self, data: dict) -> str:
        return await self.analyze(
            "Verifique quais recursos da Shopee não estamos usando: afiliados, cupons, "
            "frete grátis, Shopee Live, flash deals, bundle. Para cada recurso não usado, "
            "explique o impacto potencial e como ativar.",
            data
        )

    async def daily_report(self, data: dict) -> str:
        return await self.analyze(
            "Gere o relatório diário de performance. Compare os números, destaque o que "
            "melhorou, o que piorou e as 3 ações para amanhã. Seja direto como um gestor "
            "prestando contas.",
            data
        )

    def _format_data(self, data: dict) -> str:
        lines = []
        if "shop" in data:
            s = data["shop"]
            lines.append(f"LOJA: {s.get('name')} | Avaliação: {s.get('rating')} | Seguidores: {s.get('followers')}")

        if "summary" in data:
            s = data["summary"]
            lines.append(f"""
RESUMO GERAL:
- Investimento total em ads: R$ {s.get('total_spend', 0):.2f}
- Receita total: R$ {s.get('total_revenue', 0):.2f}
- Pedidos: {s.get('total_orders', 0)}
- ROAS médio: {s.get('avg_roas', 0):.2f}x
- Impressões: {s.get('total_impressions', 0):,}
- Cliques: {s.get('total_clicks', 0):,}
- CTR médio: {s.get('avg_ctr', 0):.2f}%""")

        if "campaigns" in data:
            lines.append("\nCAMPANHAS:")
            for c in data["campaigns"]:
                lines.append(
                    f"  [{c['status']}] {c['name']}: "
                    f"Impressões={c['impressions']:,} | Cliques={c['clicks']:,} | "
                    f"CTR={c['ctr']:.2f}% | Gasto=R${c['spend']:.2f} | "
                    f"Pedidos={c['orders']} | Receita=R${c['revenue']:.2f} | "
                    f"ROAS={c['roas']:.2f}x | CPC=R${c['cpc']:.2f}"
                )

        if "products" in data:
            lines.append("\nPRODUTOS:")
            for p in data["products"]:
                lines.append(
                    f"  {p['name']}: Preço=R${p['price']:.2f} | "
                    f"Estoque={p['stock']} | Vendidos={p['sold']} | Rating={p['rating']}"
                )

        return "\n".join(lines)


agent_service = AgentService()
