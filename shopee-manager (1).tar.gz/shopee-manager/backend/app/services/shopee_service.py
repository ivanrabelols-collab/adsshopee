import hmac
import hashlib
import time
import httpx
from typing import Optional
from app.core.config import settings


class ShopeeService:
    def __init__(self):
        self.base_url = settings.SHOPEE_API_BASE
        self.partner_id = int(settings.SHOPEE_PARTNER_ID) if settings.SHOPEE_PARTNER_ID else 0
        self.partner_key = settings.SHOPEE_PARTNER_KEY
        self.shop_id = int(settings.SHOPEE_SHOP_ID) if settings.SHOPEE_SHOP_ID else 0
        self.access_token = settings.SHOPEE_ACCESS_TOKEN

    def _sign(self, path: str, timestamp: int) -> str:
        base_str = f"{self.partner_id}{path}{timestamp}{self.access_token}{self.shop_id}"
        return hmac.new(
            self.partner_key.encode("utf-8"),
            base_str.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()

    def _headers(self) -> dict:
        return {"Content-Type": "application/json"}

    def _params(self, path: str) -> dict:
        ts = int(time.time())
        return {
            "partner_id": self.partner_id,
            "timestamp": ts,
            "access_token": self.access_token,
            "shop_id": self.shop_id,
            "sign": self._sign(path, ts),
        }

    async def get_shop_info(self) -> dict:
        path = "/shop/get_shop_info"
        async with httpx.AsyncClient() as client:
            r = await client.get(
                f"{self.base_url}{path}",
                params=self._params(path),
                headers=self._headers()
            )
            return r.json()

    async def get_products(self, offset: int = 0, limit: int = 50) -> dict:
        path = "/product/get_item_list"
        params = {**self._params(path), "offset": offset, "page_size": limit, "item_status": "NORMAL"}
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{path}", params=params)
            return r.json()

    async def get_product_detail(self, item_ids: list) -> dict:
        path = "/product/get_item_base_info"
        params = {**self._params(path), "item_id_list": ",".join(map(str, item_ids))}
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{path}", params=params)
            return r.json()

    async def get_ads_campaigns(self) -> dict:
        """Busca todas as campanhas de Shopee Ads"""
        path = "/ads/get_all_campaign"
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{path}", params=self._params(path))
            return r.json()

    async def get_campaign_performance(self, campaign_id: int, start_date: str, end_date: str) -> dict:
        """Performance de uma campanha: impressões, cliques, CTR, ROAS"""
        path = "/ads/get_campaign_by_id"
        params = {**self._params(path), "campaign_id": campaign_id}
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{path}", params=params)
            return r.json()

    async def get_ads_report(self, start_date: str, end_date: str) -> dict:
        """Relatório geral de ads no período"""
        path = "/ads/get_shop_performance"
        params = {**self._params(path), "start_date": start_date, "end_date": end_date}
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{path}", params=params)
            return r.json()

    async def get_keywords(self, item_id: int, campaign_id: int) -> dict:
        path = "/ads/get_keyword_list"
        params = {**self._params(path), "item_id": item_id, "campaign_id": campaign_id}
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{path}", params=params)
            return r.json()

    async def get_orders(self, time_from: int, time_to: int, order_status: str = "READY_TO_SHIP") -> dict:
        path = "/order/get_order_list"
        params = {
            **self._params(path),
            "time_range_field": "create_time",
            "time_from": time_from,
            "time_to": time_to,
            "page_size": 50,
            "order_status": order_status
        }
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{path}", params=params)
            return r.json()

    async def get_vouchers(self) -> dict:
        path = "/voucher/get_voucher_list"
        params = {**self._params(path), "status": 1, "page_no": 1, "page_size": 20}
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{path}", params=params)
            return r.json()

    async def get_shop_performance(self) -> dict:
        path = "/shop/get_shop_info"
        async with httpx.AsyncClient() as client:
            r = await client.get(f"{self.base_url}{path}", params=self._params(path))
            return r.json()

    async def update_campaign_budget(self, campaign_id: int, daily_budget: float) -> dict:
        path = "/ads/update_campaign"
        payload = {"campaign_id": campaign_id, "daily_budget": daily_budget}
        async with httpx.AsyncClient() as client:
            r = await client.post(
                f"{self.base_url}{path}",
                params=self._params(path),
                json=payload
            )
            return r.json()

    async def pause_campaign(self, campaign_id: int) -> dict:
        path = "/ads/update_campaign_status"
        payload = {"campaign_id": campaign_id, "status": "SUSPENDED"}
        async with httpx.AsyncClient() as client:
            r = await client.post(
                f"{self.base_url}{path}",
                params=self._params(path),
                json=payload
            )
            return r.json()

    # --- MOCK para demo sem credenciais ---
    async def get_mock_dashboard(self) -> dict:
        return {
            "shop": {"name": "Minha Loja Shopee", "rating": 4.8, "followers": 1240},
            "campaigns": [
                {"id": 1001, "name": "Produto A - Busca", "status": "ONGOING",
                 "impressions": 45200, "clicks": 1830, "ctr": 4.05, "spend": 187.50,
                 "orders": 42, "revenue": 2310.00, "roas": 12.32, "cpc": 0.10},
                {"id": 1002, "name": "Produto B - Descoberta", "status": "ONGOING",
                 "impressions": 89400, "clicks": 2100, "ctr": 2.35, "spend": 430.00,
                 "orders": 31, "revenue": 1550.00, "roas": 3.60, "cpc": 0.20},
                {"id": 1003, "name": "Produto C - Busca", "status": "SUSPENDED",
                 "impressions": 12000, "clicks": 180, "ctr": 1.50, "spend": 95.00,
                 "orders": 4, "revenue": 200.00, "roas": 2.10, "cpc": 0.53},
                {"id": 1004, "name": "Produto D - Loja", "status": "ONGOING",
                 "impressions": 33100, "clicks": 990, "ctr": 2.99, "spend": 210.00,
                 "orders": 28, "revenue": 1680.00, "roas": 8.00, "cpc": 0.21},
            ],
            "summary": {
                "total_spend": 922.50,
                "total_revenue": 5740.00,
                "total_orders": 105,
                "avg_roas": 6.22,
                "total_impressions": 179700,
                "total_clicks": 5100,
                "avg_ctr": 2.84
            },
            "products": [
                {"id": 101, "name": "Produto A", "price": 55.00, "stock": 230, "sold": 412, "rating": 4.9},
                {"id": 102, "name": "Produto B", "price": 50.00, "stock": 85, "sold": 198, "rating": 4.7},
                {"id": 103, "name": "Produto C", "price": 50.00, "stock": 12, "sold": 67, "rating": 4.5},
                {"id": 104, "name": "Produto D", "price": 60.00, "stock": 310, "sold": 289, "rating": 4.8},
            ]
        }


shopee_service = ShopeeService()
