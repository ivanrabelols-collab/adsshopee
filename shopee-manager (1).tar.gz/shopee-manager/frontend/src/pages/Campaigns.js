import React, { useEffect, useState } from 'react';
import axios from 'axios';

const API = process.env.REACT_APP_API_URL || '';

const mockCampaigns = [
  { id: 1001, name: "Produto A - Busca", status: "ONGOING", impressions: 45200, clicks: 1830, ctr: 4.05, spend: 187.50, orders: 42, revenue: 2310.00, roas: 12.32, cpc: 0.10 },
  { id: 1002, name: "Produto B - Descoberta", status: "ONGOING", impressions: 89400, clicks: 2100, ctr: 2.35, spend: 430.00, orders: 31, revenue: 1550.00, roas: 3.60, cpc: 0.20 },
  { id: 1003, name: "Produto C - Busca", status: "SUSPENDED", impressions: 12000, clicks: 180, ctr: 1.50, spend: 95.00, orders: 4, revenue: 200.00, roas: 2.10, cpc: 0.53 },
  { id: 1004, name: "Produto D - Loja", status: "ONGOING", impressions: 33100, clicks: 990, ctr: 2.99, spend: 210.00, orders: 28, revenue: 1680.00, roas: 8.00, cpc: 0.21 },
];

function roasClass(v) {
  if (v >= 8) return 'roas-good';
  if (v >= 4) return 'roas-ok';
  return 'roas-bad';
}

function StatusBadge({ status }) {
  if (status === 'ONGOING') return <span className="badge badge-green">● ATIVO</span>;
  if (status === 'SUSPENDED') return <span className="badge badge-red">● PAUSADO</span>;
  return <span className="badge badge-gray">{status}</span>;
}

export default function Campaigns() {
  const [campaigns, setCampaigns] = useState(mockCampaigns);
  const [sort, setSort] = useState({ key: 'roas', dir: -1 });

  useEffect(() => {
    axios.get(`${API}/api/shopee/campaigns?demo=true`)
      .then(r => setCampaigns(r.data))
      .catch(() => setCampaigns(mockCampaigns));
  }, []);

  const sorted = [...campaigns].sort((a, b) => sort.dir * ((a[sort.key] > b[sort.key]) ? 1 : -1));

  function toggleSort(key) {
    setSort(s => ({ key, dir: s.key === key ? -s.dir : -1 }));
  }

  const cols = [
    { key: 'name', label: 'Campanha', mono: false },
    { key: 'status', label: 'Status', render: r => <StatusBadge status={r.status} /> },
    { key: 'impressions', label: 'Impressões', fmt: v => v.toLocaleString() },
    { key: 'clicks', label: 'Cliques', fmt: v => v.toLocaleString() },
    { key: 'ctr', label: 'CTR', fmt: v => `${v.toFixed(2)}%` },
    { key: 'cpc', label: 'CPC', fmt: v => `R$ ${v.toFixed(2)}` },
    { key: 'spend', label: 'Gasto', fmt: v => `R$ ${v.toFixed(2)}` },
    { key: 'orders', label: 'Pedidos' },
    { key: 'revenue', label: 'Receita', fmt: v => `R$ ${v.toFixed(2)}` },
    { key: 'roas', label: 'ROAS', render: r => <span className={roasClass(r.roas)}>{r.roas.toFixed(2)}x</span> },
  ];

  const totals = campaigns.reduce((acc, c) => ({
    impressions: acc.impressions + c.impressions,
    clicks: acc.clicks + c.clicks,
    spend: acc.spend + c.spend,
    orders: acc.orders + c.orders,
    revenue: acc.revenue + c.revenue,
  }), { impressions: 0, clicks: 0, spend: 0, orders: 0, revenue: 0 });

  return (
    <div className="page">
      <div className="page-header">
        <div className="page-title">Campanhas de Ads</div>
        <div className="page-subtitle">Shopee Ads — Busca, Descoberta e Loja</div>
      </div>

      <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(5, 1fr)', marginBottom: 24 }}>
        {[
          { label: 'Impressões', value: totals.impressions.toLocaleString() },
          { label: 'Cliques', value: totals.clicks.toLocaleString() },
          { label: 'Gasto Total', value: `R$ ${totals.spend.toFixed(2)}`, cls: '' },
          { label: 'Pedidos', value: totals.orders, cls: 'green' },
          { label: 'Receita Total', value: `R$ ${totals.revenue.toFixed(2)}`, cls: 'green' },
        ].map(s => (
          <div key={s.label} className={`stat-card ${s.cls || ''}`}>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value" style={{ fontSize: 20 }}>{s.value}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div className="card-title" style={{ marginBottom: 0 }}>Todas as Campanhas</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <span style={{ fontSize: 11, color: 'var(--text3)' }}>Clique no cabeçalho para ordenar</span>
          </div>
        </div>

        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                {cols.map(c => (
                  <th key={c.key} onClick={() => toggleSort(c.key)} style={{ cursor: 'pointer', userSelect: 'none' }}>
                    {c.label} {sort.key === c.key ? (sort.dir === -1 ? '↓' : '↑') : ''}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sorted.map(row => (
                <tr key={row.id}>
                  {cols.map(c => (
                    <td key={c.key} style={!c.mono ? { fontFamily: 'var(--font-display)', color: 'var(--text)', fontWeight: 600, fontSize: 13 } : {}}>
                      {c.render ? c.render(row) : c.fmt ? c.fmt(row[c.key]) : row[c.key]}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div style={{ marginTop: 16, padding: '12px 14px', background: 'var(--bg3)', borderRadius: 8, fontSize: 12, color: 'var(--text3)' }}>
          💡 <strong style={{ color: 'var(--orange)' }}>ROAS ≥ 8x</strong> = excelente · 
          <strong style={{ color: 'var(--yellow)' }}> 4–8x</strong> = ok · 
          <strong style={{ color: 'var(--red)' }}> &lt;4x</strong> = revisar/pausar
        </div>
      </div>
    </div>
  );
}
