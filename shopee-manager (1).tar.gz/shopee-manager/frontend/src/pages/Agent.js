import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import axios from 'axios';

const API = process.env.REACT_APP_API_URL || '';

const QUICK_ACTIONS = [
  { id: 'audit', label: '🔍 Diagnóstico Completo', desc: 'Análise geral da conta', endpoint: '/api/agent/audit' },
  { id: 'optimize', label: '⚡ Otimizar Campanhas', desc: 'Pausar, escalar ou reformular', endpoint: '/api/agent/optimize' },
  { id: 'keywords', label: '🔑 Estratégia de Keywords', desc: 'Novas kws de alto potencial', endpoint: '/api/agent/keywords' },
  { id: 'resources', label: '🎯 Recursos Não Usados', desc: 'Afiliados, cupons, frete...', endpoint: '/api/agent/resources' },
  { id: 'report', label: '📊 Relatório Diário', desc: 'Performance de hoje', endpoint: '/api/agent/daily-report' },
];

// Simulated AI responses for demo (when no API key)
const DEMO_RESPONSES = {
  audit: `## 🔍 Diagnóstico Completo da Conta

### ✅ Pontos Positivos
- **Produto A** com ROAS de 12,32x está performando excepcionalmente — candidato a escalar budget
- CTR geral de 4,05% na campanha de busca está acima da média do mercado (2–3%)
- Loja com rating 4.8 e 1.240 seguidores tem boa base para crescimento orgânico

### 🚨 Problemas Identificados

**1. Produto C pausado com ROAS 2.10x — revisão urgente**
- CPC de R$ 0,53 é 5x maior que o Produto A (R$ 0,10)
- Possíveis causas: título fraco, foto ruim, preço fora do mercado
- Ação: reformular listing antes de reativar

**2. Produto B com ROAS 3.60x gastando R$ 430/mês**
- É a campanha mais cara e a de pior retorno entre as ativas
- Reduzir budget em 40% e testar novas palavras-chave long tail

**3. Estoque crítico do Produto C (12 unidades)**
- Risco de perder ranking ao esgotar
- Repor estoque antes de escalar qualquer campanha

### 🎯 Top 3 Oportunidades

1. **Escalar Produto A**: ROAS 12x justifica dobrar o orçamento — potencial +R$ 2.000/mês em receita
2. **Ativar Programa de Afiliados**: nenhum produto cadastrado — afiliados podem gerar 20-30% do volume sem custo upfront
3. **Criar campanhas para Produto D**: ROAS 8x sem campanha de descoberta — ampliar alcance

### 📋 Próximas Ações (esta semana)
1. Pausar Produto B por 7 dias → reformular título e foto → reativar com orçamento menor
2. Aumentar budget do Produto A de R$ 187 → R$ 350
3. Cadastrar todos os produtos no programa de afiliados Shopee`,

  optimize: `## ⚡ Otimização de Campanhas

### Produto A — Busca 🟢 ESCALAR
- **Ação**: Aumentar orçamento diário de R$ 6,25 → R$ 12,00
- **ROAS atual**: 12,32x | **Meta**: manter acima de 8x
- **Justificativa**: CTR 4,05% e CPC R$ 0,10 mostram excelente relevância
- **Lance sugerido**: manter automático com teto de R$ 0,15/clique

### Produto B — Descoberta 🟡 REFORMULAR
- **Ação**: Reduzir orçamento em 50%, focar em palavras-chave de intenção de compra
- **Problema**: ROAS 3,60x com R$ 430/mês de gasto — maior custo da conta
- **Novo budget sugerido**: R$ 200/mês
- **KWs para remover**: termos genéricos com alto CPC e baixa conversão
- **KWs para adicionar**: "{produto} original", "{produto} barato", "{produto} entrega rápida"

### Produto C — Busca 🔴 MANTER PAUSADO
- **Ação**: Não reativar até reformular o listing
- **ROAS 2,10x é insustentável** — cada R$ 1 investido retorna R$ 2,10
- Checklist antes de reativar: nova foto principal, título com KWs principais, preço competitivo

### Produto D — Loja 🟢 EXPANDIR
- **Ação**: Criar campanha de BUSCA além da de loja
- **ROAS 8x na campanha de loja** indica produto com alta demanda
- **Orçamento sugerido para nova campanha**: R$ 150/mês
- **Palavras-chave iniciais**: 5-10 termos de cauda longa

### 💰 Impacto Estimado
- Receita atual: R$ 5.740/mês
- Com otimizações: **R$ 7.800–9.200/mês (+35-60%)**
- Custo ads atual: R$ 922 → **R$ 750 (-18% de custo)**`,

  keywords: `## 🔑 Estratégia de Palavras-Chave

### Diagnóstico Atual
Baseado no nome dos seus produtos, identifiquei oportunidades em palavras-chave de **cauda longa** que têm menor concorrência e maior intenção de compra.

### 🔥 Top 10 Keywords de Alto Potencial

| Palavra-chave | Volume Est. | CPC Est. | Intenção |
|---|---|---|---|
| [produto] original importado | Alto | Baixo | Compra |
| [produto] melhor preço | Alto | Médio | Comparação |
| [produto] entrega rápida SP | Médio | Baixo | Urgência |
| comprar [produto] online | Alto | Médio | Compra |
| [produto] barato promoção | Médio | Baixo | Preço |
| [produto] qualidade | Alto | Médio | Pesquisa |
| [produto] frete grátis | Alto | Médio | Benefício |
| kit [produto] | Médio | Baixo | Bundle |
| [produto] atacado | Baixo | Baixo | B2B |
| [produto] presente | Médio | Baixo | Ocasião |

### 📂 Categorias Não Exploradas
- **Sazonais**: Dia das Mães, Natal, Black Friday — criar campanha específica por data
- **Regionais**: adicionar estado/cidade nos títulos para tráfego local
- **Complementares**: produtos que seus clientes compram junto — cross-sell via anúncios

### 💡 Dicas de Implementação
1. Adicionar as 3 melhores kws em **correspondência exata** primeiro
2. Após 7 dias, adicionar as restantes em **frase**
3. Excluir kws com 0 conversão em 50+ cliques`,
  
  resources: `## 🎯 Recursos da Shopee Não Utilizados

### 1. 🤝 Programa de Afiliados Shopee — IMPACTO ALTO
- **Status**: Nenhum produto cadastrado
- **Como funciona**: Criadores de conteúdo promovem seus produtos e ganham comissão (você define %)
- **Potencial**: 20-40% de receita adicional sem custo upfront (só paga na venda)
- **Ação**: Acessar Central do Vendedor → Marketing → Programa de Afiliados → cadastrar todos os produtos com comissão de 8-12%

### 2. 🚚 Frete Grátis Acima de X — IMPACTO ALTO
- **Status**: Não configurado
- **Impacto**: Produtos com frete grátis convertem até 3x mais
- **Ação**: Configurar frete grátis para pedidos acima de R$ 80 — cobre o custo no ticket médio

### 3. 🎟️ Cupons da Loja — IMPACTO MÉDIO
- **Status**: Nenhum cupom ativo
- **Tipos disponíveis**: % desconto, R$ fixo, frete grátis
- **Estratégia**: Criar cupom de 10% para novos seguidores + cupom de R$ 5 para recompra (enviar no chat pós-venda)

### 4. 📦 Bundle / Kit de Produtos — IMPACTO MÉDIO
- **Status**: Produtos vendidos individualmente
- **Ação**: Criar kits combinando produtos complementares com 5-8% de desconto
- **Benefício**: Aumenta ticket médio e melhora posição no algoritmo

### 5. 📱 Shopee Live — IMPACTO MÉDIO/LONGO PRAZO
- **Status**: Nunca utilizado
- **Potencial**: Lives geram pico de vendas + seguidores orgânicos
- **Sugestão**: 1 live de 30 min/semana com demonstração dos produtos

### 6. ⚡ Flash Sale — IMPACTO IMEDIATO
- **Status**: Não participando
- **Ação**: Inscrever Produto A e D nas próximas flash sales da Shopee — gera visibilidade massiva

### 🗓️ Plano de Implementação
- **Semana 1**: Afiliados + Frete Grátis (maior impacto imediato)
- **Semana 2**: Cupons + Bundle  
- **Semana 3+**: Shopee Live + Flash Sale`,

  report: `## 📊 Relatório Diário — Hoje

### Performance Geral
| Métrica | Hoje | Meta | Status |
|---|---|---|---|
| Receita | R$ 820 | R$ 750 | ✅ +9% |
| Gasto Ads | R$ 131 | R$ 150 | ✅ -12% |
| ROAS | 6,26x | 5x | ✅ Ok |
| Pedidos | 15 | 12 | ✅ +25% |
| CTR | 2,91% | 3% | 🟡 Próximo |

### 🏆 Destaque do Dia
**Produto A** gerou 60% da receita do dia com apenas 25% do orçamento. Campanha de busca com CTR de 4,2% — continua performando acima da média.

### ⚠️ Alertas
- **Produto C**: Estoque chegou a 12 unidades. Pedido de reposição urgente.
- **Produto B**: 3º dia seguido com ROAS abaixo de 4x — considerar pausar amanhã.

### 📈 Tendência da Semana
Receita acumulada: R$ 4.200 (meta semanal: R$ 5.250) — no ritmo correto para bater na sexta.

### 🎯 Ações para Amanhã
1. Aumentar lance do Produto A em +R$ 0,02/clique
2. Revisar título e foto do Produto B antes de decidir pausar
3. Emitir pedido de reposição do Produto C (mínimo 100 unidades)`
};

function LoadingDots() {
  return (
    <div className="chat-msg ai">
      <div className="msg-bubble">
        <div className="loading-dots"><span/><span/><span/></div>
      </div>
    </div>
  );
}

export default function Agent() {
  const [messages, setMessages] = useState([
    { role: 'ai', content: 'Olá! Sou seu gestor de tráfego IA para a Shopee. Tenho acesso aos dados da sua conta e posso analisar campanhas, sugerir otimizações e criar estratégias. Como posso ajudar hoje?\n\n*Use os atalhos à esquerda para análises rápidas, ou me faça qualquer pergunta.*', ts: new Date() }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  async function sendMessage(msg, endpoint = null) {
    if (!msg.trim() || loading) return;
    const userMsg = { role: 'user', content: msg, ts: new Date() };
    setMessages(m => [...m, userMsg]);
    setInput('');
    setLoading(true);

    try {
      let response;
      if (endpoint) {
        const r = await axios.post(`${API}${endpoint}?demo=true`);
        response = r.data.response;
      } else {
        const r = await axios.post(`${API}/api/agent/chat`, { message: msg, demo: true });
        response = r.data.response;
      }
      setMessages(m => [...m, { role: 'ai', content: response, ts: new Date() }]);
    } catch (e) {
      // Demo fallback
      const demoKey = Object.keys(DEMO_RESPONSES).find(k => endpoint?.includes(k)) || 'audit';
      const demo = endpoint ? DEMO_RESPONSES[demoKey] : `Sem conexão com o backend. Configure a API key da Anthropic no .env e inicie o servidor.\n\n**Demo**: ${DEMO_RESPONSES.audit}`;
      setMessages(m => [...m, { role: 'ai', content: demo, ts: new Date() }]);
    } finally {
      setLoading(false);
    }
  }

  function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  }

  function fmt(ts) {
    return ts.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  }

  return (
    <div className="page" style={{ paddingBottom: 0 }}>
      <div className="page-header">
        <div className="page-title">Agente IA</div>
        <div className="page-subtitle">Gestor de tráfego inteligente com dados reais da sua conta</div>
      </div>

      <div className="agent-layout">
        <div>
          <div className="card-title">Análises Rápidas</div>
          <div className="agent-actions">
            {QUICK_ACTIONS.map(a => (
              <button key={a.id} className="action-btn" onClick={() => sendMessage(a.label, a.endpoint)}>
                <strong>{a.label}</strong>
                <span>{a.desc}</span>
              </button>
            ))}
          </div>
          <div style={{ marginTop: 16, padding: 12, background: 'var(--bg3)', borderRadius: 8, border: '1px solid var(--border)' }}>
            <div style={{ fontSize: 11, color: 'var(--text3)', fontWeight: 700, letterSpacing: '0.06em', marginBottom: 6 }}>SUGESTÕES</div>
            {['Quais palavras-chave devo pausar?', 'Como melhorar meu CTR?', 'Devo investir mais em Produto A?'].map(s => (
              <button key={s} onClick={() => sendMessage(s)} style={{ display: 'block', width: '100%', textAlign: 'left', background: 'none', border: 'none', color: 'var(--text2)', fontSize: 12, padding: '5px 0', cursor: 'pointer', borderBottom: '1px solid var(--border)' }}>
                → {s}
              </button>
            ))}
          </div>
        </div>

        <div className="chat-area">
          <div className="chat-messages">
            {messages.map((m, i) => (
              <div key={i} className={`chat-msg ${m.role}`}>
                <div className="msg-bubble">
                  {m.role === 'ai' ? <ReactMarkdown>{m.content}</ReactMarkdown> : m.content}
                </div>
                <div className="msg-time">{fmt(m.ts)}</div>
              </div>
            ))}
            {loading && <LoadingDots />}
            <div ref={bottomRef} />
          </div>

          <div className="chat-input-row">
            <textarea
              className="chat-input"
              rows={2}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Pergunte qualquer coisa sobre sua conta... (Enter para enviar)"
            />
            <button className="btn btn-primary" onClick={() => sendMessage(input)} disabled={loading || !input.trim()}>
              {loading ? '...' : '→'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
