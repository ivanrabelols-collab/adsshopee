import React, { useEffect, useState } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import axios from 'axios';

const API = process.env.REACT_APP_API_URL || '';

const mockData = {
  shop: { name: "Minha Loja Shopee", rating: 4.8, followers: 1240 },
  summary: { total_spend: 922.50, total_revenue: 5740.00, total_orders: 105, avg_roas: 6.22, total_impressions: 179700, total_clicks: 5100, avg_ctr: 2.84 },
  campaigns: [
    { id: 1001, name: "Produto A - Busca", status: "ONGOING", impressions: 45200, clicks: 1830, ctr: 4.05, spend: 187.50, orders: 42, revenue: 2310.00, roas: 12.32 },
    { id: 1002, name: "Produto B - Descoberta", status: "ONGOING", impressions: 89400, clicks: 2100, ctr: 2.35, spend: 430.00, orders: 31, revenue: 1550.00, roas: 3.60 },
    { id: 1003, name: "Produto C - Busca", status: "SUSPENDED", impressions: 12000, clicks: 180, ctr: 1.50, spend: 95.00, orders: 4, revenue: 200.00, roas: 2.10 },
    { id: 1004, name: "Produto D - Loja", status: "ONGOING", impressions: 33100, clicks: 990, ctr: 2.99, spend: 210.00, orders: 28, revenue: 1680.00, roas: 8.00 },
  ],
  products: [
    { id: 101, name: "Produto A", price: 55.00, stock: 230, sold: 412, rating: 4.9 },
    { id: 102, name: "Produto B", price: 50.00, stock: 85, sold: 198, rating: 4.7 },
    { id: 103, name: "Produto C", price: 50.00, stock: 12, sold: 67, rating: 4.5 },
    { id: 104, name: "Produto D", price: 60.00, stock: 310, sold: 289, rating: 4.8 },
  ]
};

const weekData = [
  { day: 'Seg', revenue: 820, spend: 130 },
  { day: 'Ter', revenue: 940, spend: 145 },
  { day: 'Qua', revenue: 710, spend: 120 },
  { day: 'Qui', revenue: 1050, spend: 160 },
  { day: 'Sex', revenue: 1280, spend: 190 },
  { day: 'Sáb', revenue: 1540, spend: 210 },
  { day: 'Dom', revenue: 1100, spend: 170 },
];

function fmt(v, prefix = 'R$') {
  if (v >= 1000) return `${prefix} ${(v/1000).toFixed(1)}k`;
  return `${prefix} ${v.toFixed(2)}`;
}

const tooltipStyle = {
  contentStyle: { background: '#1c1c21', border: '1px solid #2a2a30', borderRadius: 8, fontFamily: 'DM Mono, monospace', fontSize: 12 },
  labelStyle: { color: '#9090a0' },
};

export default function Dashboard() {
  const [data, setData] = useState(mockData);

  useEffect(() => {
    axios.get(`${API}/api/shopee/dashboard?demo=true`)
      .then(r => setData(r.data))
      .catch(() => setData(mockData));
  }, []);

  const s = data.summary || {};
  const stats = [
    { label: 'Receita Total', value: fmt(s.total_revenue || 0), sub: 'últimos 7 dias', cls: 'green' },
    { label: 'Investimento Ads', value: fmt(s.total_spend || 0), sub: `ROAS ${(s.avg_roas || 0).toFixed(2)}x`, cls: '' },
    { label: 'Pedidos', value: s.total_orders || 0, sub: `${(s.total_clicks || 0).toLocaleString()} cliques`, cls: 'green' },
    { label: 'CTR Médio', value: `${(s.avg_ctr || 0).toFixed(2)}%`, sub: `${(s.total_impressions || 0).toLocaleString()} impressões`, cls: 'yellow' },
  ];

  const roasData = (data.campaigns || []).map(c => ({ name: c.name.split(' - ')[0], roas: c.roas, revenue: c.revenue }));

  return (
    <div className="page">
      <div className="page-header">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div className="page-title">Dashboard</div>
            <div className="page-subtitle">
              {data.shop?.name} · ⭐ {data.shop?.rating} · {data.shop?.followers?.toLocaleString()} seguidores
            </div>
          </div>
          <span className="demo-badge">DEMO DATA</span>
        </div>
      </div>

      <div className="stats-grid">
        {stats.map(st => (
          <div key={st.label} className={`stat-card ${st.cls}`}>
            <div className="stat-label">{st.label}</div>
            <div className="stat-value">{st.value}</div>
            <div className="stat-sub">{st.sub}</div>
          </div>
        ))}
      </div>

      <div className="chart-grid">
        <div className="card">
          <div className="card-title">Receita vs Investimento (7 dias)</div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={weekData} {...tooltipStyle}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a30" />
              <XAxis dataKey="day" tick={{ fill: '#9090a0', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#9090a0', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `R$${v}`} />
              <Tooltip {...tooltipStyle} formatter={v => [`R$ ${v}`, '']} />
              <Line type="monotone" dataKey="revenue" stroke="#00c896" strokeWidth={2} dot={false} name="Receita" />
              <Line type="monotone" dataKey="spend" stroke="#ff5722" strokeWidth={2} dot={false} name="Investimento" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="card-title">ROAS por Campanha</div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={roasData} barSize={28}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a2a30" vertical={false} />
              <XAxis dataKey="name" tick={{ fill: '#9090a0', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: '#9090a0', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip {...tooltipStyle} formatter={v => [`${v}x`, 'ROAS']} />
              <Bar dataKey="roas" radius={[4, 4, 0, 0]}>
                {roasData.map((e, i) => (
                  <Cell key={i} fill={e.roas >= 8 ? '#00c896' : e.roas >= 4 ? '#ffcc00' : '#ff4444'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <div className="card-title">Produtos</div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Produto</th>
                <th>Preço</th>
                <th>Estoque</th>
                <th>Vendidos</th>
                <th>Rating</th>
              </tr>
            </thead>
            <tbody>
              {(data.products || []).map(p => (
                <tr key={p.id}>
                  <td style={{ color: 'var(--text)', fontFamily: 'var(--font-display)', fontWeight: 600 }}>{p.name}</td>
                  <td>R$ {p.price.toFixed(2)}</td>
                  <td style={{ color: p.stock < 20 ? 'var(--red)' : 'var(--text2)' }}>{p.stock}</td>
                  <td style={{ color: 'var(--green)' }}>{p.sold}</td>
                  <td>⭐ {p.rating}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
