import React from 'react';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Campaigns from './pages/Campaigns';
import Agent from './pages/Agent';
import './App.css';

function Sidebar() {
  const links = [
    { to: '/', label: 'Dashboard', icon: '◈' },
    { to: '/campaigns', label: 'Campanhas', icon: '◉' },
    { to: '/agent', label: 'Agente IA', icon: '◎' },
  ];
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <span className="brand-icon">🛒</span>
        <span className="brand-name">Shopee<br/><em>Manager</em></span>
      </div>
      <nav className="sidebar-nav">
        {links.map(l => (
          <NavLink key={l.to} to={l.to} end={l.to === '/'} className={({isActive}) => `nav-link ${isActive ? 'active' : ''}`}>
            <span className="nav-icon">{l.icon}</span>
            {l.label}
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="demo-badge">MODO DEMO</div>
        <p>Conecte sua API<br/>Shopee no .env</p>
      </div>
    </aside>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="app-layout">
        <Sidebar />
        <main className="app-main">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/campaigns" element={<Campaigns />} />
            <Route path="/agent" element={<Agent />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
